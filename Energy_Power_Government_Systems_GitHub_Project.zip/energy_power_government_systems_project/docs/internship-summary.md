# Internship learning summary

## Topic
Study of Government Systems and Administrative Procedures in the Energy and Power Sector.

## Six learning objectives
1. Understand government organisational structure and hierarchy.
2. Learn administrative procedures and office protocols.
3. Study relevant Acts, rules and regulations.
4. Understand budgeting and financial management.
5. Study government energy schemes and programmes.
6. Understand inter-departmental coordination and communication.

## Core learning
Energy projects depend on engineering as well as policy, approvals, budgeting, procurement, regulation, monitoring and coordination. In India, electricity is a Concurrent List subject, and both Union and State institutions have roles.

## Official starting points
- Ministry of Power: https://powermin.gov.in/
- MNRE: https://mnre.gov.in/en/
- India Code: https://www.indiacode.nic.in/
- BEE: https://beeindia.gov.in/
- CEA: https://cea.nic.in/
