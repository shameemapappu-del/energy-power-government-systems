# Government Systems in the Energy & Power Sector

A small educational GitHub project prepared alongside an internship report. It presents a structured overview of India's energy and power governance system, key institutions, selected laws, schemes and the administrative workflow behind public energy projects.

## Project objective
To connect Energy and Environmental Engineering with public administration by organising essential information about:
- Government hierarchy and institutions
- Administrative file and project workflow
- Major electricity and energy-efficiency legislation
- Public budgeting and expenditure stages
- Selected government energy programmes
- Inter-departmental coordination

## Run locally
No installation is required. Open `index.html` in a web browser.

## Repository structure
```text
energy-power-government-systems/
├── index.html
├── styles.css
├── script.js
├── README.md
├── data/
│   └── schemes.json
└── docs/
    └── internship-summary.md
```

## Important note
This is an educational reference project, not an official Government of India portal. Scheme details, eligibility, subsidy values and legal provisions can change. Always verify current information through the linked official sources. The content is a high-level learning summary and not legal or financial advice.

## Suggested GitHub description
Educational project explaining India's energy and power governance structure, administrative workflow, key laws, public budgeting and government energy schemes.

## Suggested topics
`energy` `power-sector` `renewable-energy` `india` `government` `internship` `energy-policy` `html-css-javascript`
